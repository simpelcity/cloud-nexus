# Kleuren
- primair: #4A90E2
- secundair: #8ED6FF
- groen/succes: #2ecc71
- wit: #FFFFFF
- wit-accent (light): #f5f6fa

# Lettertypes
- titels en headings: [Ubuntu Mono](https://fonts.google.com/specimen/Ubuntu+Mono)
- body: [Nunito](https://fonts.google.com/specimen/Nunito)